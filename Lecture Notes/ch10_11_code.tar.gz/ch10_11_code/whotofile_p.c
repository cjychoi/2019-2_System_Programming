/* whotofile.c
 *	purpose	: show how to redirect output for another program
 *	idea	:  fork, then in the child, redirect output, then exec
 */

#include	<stdio.h>
#include	<unistd.h>	/* for execlp */
#include	<stdlib.h>	/* for exit   */

main()
{
	int pid;
	int fd;

	printf("About to run who into a file\n");
	
	/* create a new process or quit */
    //todo

	/* child does the work */
    //todo

	/* parent waits then reports */
    //todo

}

